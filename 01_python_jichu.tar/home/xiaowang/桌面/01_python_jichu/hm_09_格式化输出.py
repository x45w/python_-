
name = "大小明"
print("我的名字叫%s,请多多关照!" %name)

student_no=2
print("我的学号是 %06d"%student_no)

price = 8.5
weight= 7.5
money = price * weight
print("苹果单价 %.2f 元/斤,购买了 %.3f 斤,需要支付 %.4f 元"%(price,weight,money))

scale=0.025
print("数据比例:%.2f%%"%scale*100)
print("数据比例:%.2f%%"%(scale*100))
