# zhe shi di yi ge zhu shi
print("hello hello")

"""
zhe shi yi ge 
.....
.....
"""
# di er ge
print("hello world")  # shu chu huan ying xin x