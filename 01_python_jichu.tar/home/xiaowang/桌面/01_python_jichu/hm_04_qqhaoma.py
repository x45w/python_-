# ding yi bian liang ji lu qq hao ma
qq_number="1234567"

# qq mi ma
qq_passwd="123"
print(qq_number)
print(qq_passwd)