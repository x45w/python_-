# 1.提示输入苹果的单价
price =float(input("苹果单价:"))

# 2.提示用户输入苹果的重量
weight =float(input("苹果重量:"))
# 3.计算金额
money=price * weight
print(money)