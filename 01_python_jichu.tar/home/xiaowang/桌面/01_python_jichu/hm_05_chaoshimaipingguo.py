
price=8.5


weight=7.5


money=weight*price

money=money -5


print(money)