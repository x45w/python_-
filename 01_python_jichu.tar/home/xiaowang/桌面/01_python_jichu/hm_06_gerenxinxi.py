name="xiao ming"

age=18
gender=True
height=1.75
weight=75

print(name)

